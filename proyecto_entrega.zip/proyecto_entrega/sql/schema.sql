CREATE DATABASE IF NOT EXISTS tpdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'proyecto_user'@'localhost' IDENTIFIED BY 'Secreta123!';
GRANT ALL PRIVILEGES ON tpdb.* TO 'proyecto_user'@'localhost';
FLUSH PRIVILEGES;
USE tpdb;


-- schema.sql — Estructura de la base de datos tpdb

DROP TABLE IF EXISTS microchip;
DROP TABLE IF EXISTS mascota;

CREATE TABLE mascota (
    id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    especie VARCHAR(50) NOT NULL,
    raza VARCHAR(50),
    fecha_nacimiento DATE,
    sexo CHAR(1),
    UNIQUE(nombre, fecha_nacimiento)
);

CREATE TABLE microchip (
    id INT PRIMARY KEY AUTO_INCREMENT,
    codigo VARCHAR(50) NOT NULL UNIQUE,
    mascota_id INT NOT NULL,
    FOREIGN KEY (mascota_id) REFERENCES mascota(id)
);
-- seed.sql — Datos de prueba para tpdb

-- Insertar mascotas
INSERT INTO mascota (id, nombre, especie, raza, fecha_nacimiento, sexo) VALUES
(1, 'Fido', 'Canino', 'Labrador', '2020-01-01', 'M'),
(19, 'Roxy', 'Felino', 'Siames', '2019-05-10', 'F');

-- Insertar microchips asociados
INSERT INTO microchip (id, codigo, mascota_id) VALUES
(5, 'MC-1700000000000', 1),
(16, 'MC-1700000000019', 19);
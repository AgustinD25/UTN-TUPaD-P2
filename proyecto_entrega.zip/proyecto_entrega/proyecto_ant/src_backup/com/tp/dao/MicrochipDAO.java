﻿package com.tp.dao;

import com.tp.model.Microchip;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MicrochipDAO {
  private final Connection conn;
  public MicrochipDAO(Connection conn) { this.conn = conn; }

  public int insertar(Microchip mc) throws SQLException {
    String sql = \"INSERT INTO Microchip (codigo, fecha_implante, lugar_implante, mascota_id) VALUES (?, ?, ?, ?)\";
    try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
      ps.setString(1, mc.getCodigo());
      ps.setDate(2, mc.getFechaImplante() != null ? Date.valueOf(mc.getFechaImplante()) : null);
      ps.setString(3, mc.getLugarImplante());
      ps.setInt(4, mc.getMascotaId());
      ps.executeUpdate();
      try (ResultSet rs = ps.getGeneratedKeys()) {
        if (rs.next()) return rs.getInt(1);
      }
    }
    return -1;
  }

  public List<Microchip> listarPorMascota(int mascotaId) throws SQLException {
    List<Microchip> out = new ArrayList<>();
    String sql = \"SELECT * FROM Microchip WHERE mascota_id = ?\";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
      ps.setInt(1, mascotaId);
      try (ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
          Microchip mc = new Microchip();
          mc.setId(rs.getInt(\"id\"));
          mc.setCodigo(rs.getString(\"codigo\"));
          Date d = rs.getDate(\"fecha_implante\");
          if (d != null) mc.setFechaImplante(d.toLocalDate());
          mc.setLugarImplante(rs.getString(\"lugar_implante\"));
          mc.setMascotaId(rs.getInt(\"mascota_id\"));
          out.add(mc);
        }
      }
    }
    return out;
  }
}

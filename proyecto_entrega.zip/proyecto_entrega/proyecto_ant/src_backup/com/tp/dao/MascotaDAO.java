﻿package com.tp.dao;

import com.tp.model.Mascota;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MascotaDAO {
  private final Connection conn;
  public MascotaDAO(Connection conn) { this.conn = conn; }

  public int insertar(Mascota m) throws SQLException {
    String sql = \"INSERT INTO Mascota (nombre, especie, raza, fecha_nacimiento, sexo) VALUES (?, ?, ?, ?, ?)\";
    try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
      ps.setString(1, m.getNombre());
      ps.setString(2, m.getEspecie());
      ps.setString(3, m.getRaza());
      ps.setDate(4, m.getFechaNacimiento() != null ? Date.valueOf(m.getFechaNacimiento()) : null);
      ps.setString(5, m.getSexo() != null ? m.getSexo().toString() : null);
      ps.executeUpdate();
      try (ResultSet rs = ps.getGeneratedKeys()) {
        if (rs.next()) return rs.getInt(1);
      }
    }
    return -1;
  }

  public Optional<Mascota> buscarPorId(int id) throws SQLException {
    String sql = \"SELECT * FROM Mascota WHERE id = ?\";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
      ps.setInt(1, id);
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          Mascota m = new Mascota();
          m.setId(rs.getInt(\"id\"));
          m.setNombre(rs.getString(\"nombre\"));
          m.setEspecie(rs.getString(\"especie\"));
          m.setRaza(rs.getString(\"raza\"));
          Date d = rs.getDate(\"fecha_nacimiento\");
          if (d != null) m.setFechaNacimiento(d.toLocalDate());
          String s = rs.getString(\"sexo\");
          m.setSexo(s != null && s.length() > 0 ? s.charAt(0) : null);
          return Optional.of(m);
        }
      }
    }
    return Optional.empty();
  }

  public List<Mascota> listarTodas() throws SQLException {
    List<Mascota> out = new ArrayList<>();
    String sql = \"SELECT * FROM Mascota\";
    try (Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(sql)) {
      while (rs.next()) {
        Mascota m = new Mascota();
        m.setId(rs.getInt(\"id\"));
        m.setNombre(rs.getString(\"nombre\"));
        Date d = rs.getDate(\"fecha_nacimiento\");
        if (d != null) m.setFechaNacimiento(d.toLocalDate());
        out.add(m);
      }
    }
    return out;
  }
}

﻿package com.tp;
import com.tp.model.Mascota;
import com.tp.model.Microchip;
import com.tp.dao.MascotaDAO;
import com.tp.dao.MicrochipDAO;
import java.sql.*;
import java.time.LocalDate;
import java.util.Properties;
import java.io.FileInputStream;

public class AppMain {
  public static void main(String[] args) {
    try {
      Properties p = new Properties();
      p.load(new FileInputStream(\"build.properties\"));
      String url = p.getProperty(\"db.url\");
      String user = p.getProperty(\"db.user\");
      String pass = p.getProperty(\"db.pass\");

      try (Connection conn = DriverManager.getConnection(url, user, pass)) {
        conn.setAutoCommit(false);
        MascotaDAO mdao = new MascotaDAO(conn);
        MicrochipDAO mcdao = new MicrochipDAO(conn);

        Mascota m = new Mascota(null, \"Fido\", \"Canino\", \"Labrador\", LocalDate.of(2020,1,1), 'M');
        int mid = mdao.insertar(m);
        if (mid <= 0) throw new SQLException(\"No se pudo insertar mascota\");
        Microchip mc = new Microchip(null, \"MC-\" + System.currentTimeMillis(), LocalDate.now(), \"Clinica X\", mid);
        int mcid = mcdao.insertar(mc);
        if (mcid <= 0) throw new SQLException(\"No se pudo insertar microchip\");

        conn.commit();
        System.out.println(\"Inserción OK: mascotaId=\" + mid + \" microchipId=\" + mcid);
        mdao.listarTodas().forEach(x -> System.out.println(\"Mascota: \" + x.getId() + \" \" + x.getNombre()));
      } catch (Exception e) {
        System.err.println(\"Error DB: \" + e.getMessage());
        e.printStackTrace(System.err);
      }
    } catch (Exception ex) {
      System.err.println(\"No se pudo leer build.properties: \" + ex.getMessage());
    }
  }
}

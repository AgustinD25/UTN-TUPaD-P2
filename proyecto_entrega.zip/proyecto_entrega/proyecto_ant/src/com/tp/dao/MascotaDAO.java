package com.tp.dao;

import com.tp.model.Mascota;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class MascotaDAO {
  private final Connection conn;
  public MascotaDAO(Connection conn) { this.conn = conn; }

  
  
  // Inserción idempotente: usamos ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)
// para que getGeneratedKeys() devuelva el id existente o el id nuevo.
  public int insertar(Mascota m) throws SQLException {
    String sql = "INSERT INTO Mascota (nombre, especie, raza, fecha_nacimiento, sexo) " +
                 "VALUES (?, ?, ?, ?, ?) " +
                 "ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id)";
    try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
      ps.setString(1, m.getNombre());
      ps.setString(2, m.getEspecie());
      ps.setString(3, m.getRaza());
      if (m.getFechaNacimiento() != null) {
        ps.setDate(4, Date.valueOf(m.getFechaNacimiento()));
      } else {
        ps.setNull(4, Types.DATE);
      }
      if (m.getSexo() != null) {
        ps.setString(5, m.getSexo().toString());
      } else {
        ps.setNull(5, Types.VARCHAR);
      }

      ps.executeUpdate();
      try (ResultSet rs = ps.getGeneratedKeys()) {
        if (rs.next()) {
          return rs.getInt(1); // devuelve id nuevo o id existente gracias a LAST_INSERT_ID
        } else {
          throw new SQLException("No se obtuvo id tras insertar/obtener Mascota");
        }
      }
    }
  }

  public Optional<Mascota> buscarPorId(int id) throws SQLException {
    String sql = "SELECT * FROM Mascota WHERE id = ?";
    try (PreparedStatement ps = conn.prepareStatement(sql)) {
      ps.setInt(1, id);
      try (ResultSet rs = ps.executeQuery()) {
        if (rs.next()) {
          Mascota m = new Mascota();
          m.setId(rs.getInt("id"));
          m.setNombre(rs.getString("nombre"));
          m.setEspecie(rs.getString("especie"));
          m.setRaza(rs.getString("raza"));
          Date d = rs.getDate("fecha_nacimiento");
          if (d != null) m.setFechaNacimiento(d.toLocalDate());
          String s = rs.getString("sexo");
          m.setSexo(s != null && s.length() > 0 ? s.charAt(0) : null);
          return Optional.of(m);
        }
      }
    }
    return Optional.empty();
  }

  public List<Mascota> listarTodas() throws SQLException {
    List<Mascota> out = new ArrayList<>();
    String sql = "SELECT * FROM Mascota";
    try (Statement st = conn.createStatement();
         ResultSet rs = st.executeQuery(sql)) {
      while (rs.next()) {
        Mascota m = new Mascota();
        m.setId(rs.getInt("id"));
        m.setNombre(rs.getString("nombre"));
        Date d = rs.getDate("fecha_nacimiento");
        if (d != null) m.setFechaNacimiento(d.toLocalDate());
        out.add(m);
      }
    }
    return out;
  }
}

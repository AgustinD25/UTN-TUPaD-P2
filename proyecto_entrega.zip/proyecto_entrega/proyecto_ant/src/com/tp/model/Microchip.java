package com.tp.model;
import java.time.LocalDate;

import java.time.LocalDate;

public class Microchip {
  private Integer id;
  private String codigo;
  private LocalDate fechaImplante;
  private String lugarImplante;
  private Integer mascotaId;

  public Microchip() {}

  public Microchip(Integer id, String codigo, LocalDate fechaImplante, String lugarImplante, Integer mascotaId) {
    this.id = id;
    this.codigo = codigo;
    this.fechaImplante = fechaImplante;
    this.lugarImplante = lugarImplante;
    this.mascotaId = mascotaId;
  }

  public Integer getId() { return id; }
  public void setId(Integer id) { this.id = id; }
  public String getCodigo() { return codigo; }
  public void setCodigo(String codigo) { this.codigo = codigo; }
  public LocalDate getFechaImplante() { return fechaImplante; }
  public void setFechaImplante(LocalDate fechaImplante) { this.fechaImplante = fechaImplante; }
  public String getLugarImplante() { return lugarImplante; }
  public void setLugarImplante(String lugarImplante) { this.lugarImplante = lugarImplante; }
  public Integer getMascotaId() { return mascotaId; }
  public void setMascotaId(Integer mascotaId) { this.mascotaId = mascotaId; }
}

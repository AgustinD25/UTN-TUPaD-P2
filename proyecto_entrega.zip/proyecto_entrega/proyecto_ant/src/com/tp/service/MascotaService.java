package com.tp.service;

import com.tp.dao.MascotaDAO;
import com.tp.dao.MicrochipDAO;
import com.tp.model.Mascota;
import com.tp.model.Microchip;
import java.sql.Connection;
import java.sql.SQLException;

public class MascotaService {
  private final Connection conn;
  private final MascotaDAO mascotaDao;
  private final MicrochipDAO microchipDao;

  public MascotaService(Connection conn) {
    this.conn = conn;
    this.mascotaDao = new MascotaDAO(conn);
    this.microchipDao = new MicrochipDAO(conn);
  }

  
   
  public int[] insertarConMicrochip(Mascota m, String numeroMicrochip) throws SQLException {
    boolean originalAuto = conn.getAutoCommit();
    try {
      conn.setAutoCommit(false);

      int mascotaId = mascotaDao.insertar(m);

      // Crear objeto Microchip y setear valores básicos
      Microchip mc = new Microchip();
      mc.setMascotaId(mascotaId);
      mc.setCodigo(numeroMicrochip);         
    
      // Inserta microchip usando tu MicrochipDAO (misma Connection)
      int microchipId = microchipDao.insertar(mc);

      conn.commit();
      return new int[] { mascotaId, microchipId };
    } catch (SQLException ex) {
      try { conn.rollback(); } catch (SQLException rb) { /* opcional: log */ }
      throw ex;
    } finally {
      try { conn.setAutoCommit(originalAuto); } catch (SQLException e) { /* ignorar */ }
    }
  }
}

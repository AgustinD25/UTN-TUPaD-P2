package com.tp;

import com.tp.model.Mascota;
import com.tp.service.MascotaService;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.util.Properties;
import java.util.Scanner;

public class AppMain {
  public static void main(String[] args) {
    Properties p = new Properties();
    try {
      p.load(new FileInputStream("build.properties"));
    } catch (Exception ex) {
      System.err.println("No se pudo leer build.properties: " + ex.getMessage());
      ex.printStackTrace(System.err);
      return;
    }

    String url = p.getProperty("db.url");
    String user = p.getProperty("db.user");
    String pass = p.getProperty("db.pass");

    try (Scanner sc = new Scanner(System.in);
         Connection conn = DriverManager.getConnection(url, user, pass)) {

      MascotaService svc = new MascotaService(conn);

      System.out.print("Nombre: ");
      String nombre = sc.nextLine().trim();

      System.out.print("Especie: ");
      String especie = sc.nextLine().trim();

      System.out.print("Raza (ENTER para nulo): ");
      String raza = sc.nextLine().trim();
      if (raza.isEmpty()) raza = null;

      System.out.print("Fecha nacimiento (YYYY-MM-DD) o ENTER: ");
      String fechaStr = sc.nextLine().trim();
      LocalDate fecha = fechaStr.isEmpty() ? null : LocalDate.parse(fechaStr);

      System.out.print("Sexo (M/F) o ENTER: ");
      String s = sc.nextLine().trim();
      Character sexo = s.isEmpty() ? null : s.charAt(0);

      Mascota m = new Mascota(null, nombre, especie, raza, fecha, sexo);

      String codigoMicrochip = "MC-" + System.currentTimeMillis();

      try {
        int[] ids = svc.insertarConMicrochip(m, codigoMicrochip);
        System.out.println("Inserción OK: mascotaId=" + ids[0] + " microchipId=" + ids[1]);
        new com.tp.dao.MascotaDAO(conn).listarTodas()
            .forEach(x -> System.out.println("Mascota: " + x.getId() + " " + x.getNombre()));
      } catch (Exception ex) {
        System.err.println("Error DB: " + ex.getMessage());
        ex.printStackTrace(System.err);
      }

    } catch (Exception e) {
      System.err.println("Error al conectar o leer entradas: " + e.getMessage());
      e.printStackTrace(System.err);
    }
  }
}
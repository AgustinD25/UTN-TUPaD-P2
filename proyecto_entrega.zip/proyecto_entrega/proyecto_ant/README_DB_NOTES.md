﻿IMPORTANTE
- Para ejecutar la inserción necesitas agregar el JAR del conector MySQL en la carpeta lib.
  Ejemplo: lib\mysql-connector-java-8.0.33.jar
- Ajustá build.properties con la URL, usuario y contraseña de tu BD.
- Luego ejecutá:
    & 'C:\tools\apache-ant\apache-ant-1.10.15\bin\ant.bat' run-example

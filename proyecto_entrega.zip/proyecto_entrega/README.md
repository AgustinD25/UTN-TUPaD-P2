proyecto\_ant — Instrucciones de entrega

Resumen
Proyecto Java/Ant que inserta registros de Mascota y Microchip en MySQL.
Características clave: inserción idempotente de Mascota y operaciones transaccionales.

Contenido del repositorio

* src/: código fuente (modelos, DAOs, service, AppMain interactivo).
* sql/schema.sql: script para crear tablas.
* sql/seed.sql: datos de ejemplo opcionales.
* build.properties.example: propiedades de ejemplo (renombrar a build.properties).
* output\_ejecucion.txt: ejemplo de salida de consola.
* README.md: este archivo.

Preparar la base de datos (pasos exactos)

1. Crear la base y el usuario (ajustá según tu entorno):
   CREATE DATABASE tpdb CHARACTER SET utf8mb4 COLLATE utf8mb4\_unicode\_ci;
   CREATE USER 'proyecto\_user'@'localhost' IDENTIFIED BY 'su\_password';
   GRANT ALL PRIVILEGES ON tpdb.\* TO 'proyecto\_user'@'localhost';
   FLUSH PRIVILEGES;
2. Ejecutar el script de esquema:
   mysql -u proyecto\_user -p tpdb < sql/schema.sql
3. (Opcional) Poblar datos de prueba:
   mysql -u proyecto\_user -p tpdb < sql/seed.sql

Configurar build.properties

1. Copiar y renombrar:
   cp build.properties.example build.properties
2. Editar build.properties y completar db.user y db.pass.

Compilar y ejecutar

* Desde NetBeans: Project → Clean and Build → Run Project.
* Desde línea de comandos:
  java -cp ".\\dist\\proyecto\_ant.jar;.\\dist\\lib\\mysql-connector-j-9.5.0.jar" com.tp.AppMain

Pruebas recomendadas

1. Idempotencia: ejecutar la misma inserción dos veces — el mascotaId devuelto debe ser el mismo.
2. Inserción nueva: cambiar al menos nombre o fecha\_nacimiento y verificar id distinto.
3. Atomicidad / rollback: simular un fallo en la inserción del microchip y comprobar que la mascota no queda persistida.

Ejemplo de salida de ejecución
run:
Nombre: Tobi
Especie: Perro
Raza (ENTER para nulo): Labrador
Fecha nacimiento (YYYY-MM-DD) o ENTER: 2002-09-23
Sexo (M/F) o ENTER: M
Inserción OK: mascotaId=20 microchipId=17
Mascota: 1 Fido
Mascota: 19 Roxy
Mascota: 20 Tobi
BUILD SUCCESSFUL (total time: 46 seconds)

Notas técnicas (clave)

* Idempotencia MascotaDAO: se usa INSERT ... ON DUPLICATE KEY UPDATE id = LAST\_INSERT\_ID(id).
* Transacciones: MascotaService coordina setAutoCommit(false) / commit() / rollback().
* DAOs: deben recibir la misma Connection en su constructor y NO abrir nuevas conexiones internamente.

Commit sugerido
Add interactive AppMain, transactional MascotaService; include DB scripts and example properties


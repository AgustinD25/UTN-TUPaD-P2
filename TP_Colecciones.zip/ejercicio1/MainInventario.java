public class MainInventario {

    public static void main(String[] args) {

        Inventario inv = new Inventario();

        inv.agregarProducto(new Producto("A1", "Leche", 1200, 10, CategoriaProducto.ALIMENTOS));
        inv.agregarProducto(new Producto("E1", "Auriculares", 5000, 5, CategoriaProducto.ELECTRONICA));
        inv.agregarProducto(new Producto("R1", "Remera", 2500, 12, CategoriaProducto.ROPA));
        inv.agregarProducto(new Producto("H1", "Toalla", 1800, 7, CategoriaProducto.HOGAR));
        inv.agregarProducto(new Producto("A2", "Pan", 900, 20, CategoriaProducto.ALIMENTOS));

        System.out.println("LISTA:");
        inv.listarProductos();

        System.out.println("\nBuscar R1:");
        Producto p = inv.buscarProductoPorId("R1");
        if (p != null) p.mostrarInfo();

        System.out.println("\nALIMENTOS:");
        inv.filtrarPorCategoria(CategoriaProducto.ALIMENTOS);

        System.out.println("\nEliminar A2:");
        inv.eliminarProducto("A2");
        inv.listarProductos();

        inv.actualizarStock("E1", 9);

        System.out.println("\nTotal: " + inv.obtenerTotalStock());
        System.out.println("Mayor stock: " + inv.obtenerProductoConMayorStock());

        System.out.println("\nPrecio 1000-3000:");
        inv.filtrarProductosPorPrecio(1000, 3000);

        System.out.println("\nCategorias:");
        inv.mostrarCategoriasDisponibles();
    }
}
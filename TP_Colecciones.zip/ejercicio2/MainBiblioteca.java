public class MainBiblioteca {

    public static void main(String[] args) {

        Biblioteca b = new Biblioteca("Biblioteca Central");

        Autor a1 = new Autor("AU1", "Gabriel García Márquez", "Colombiano");
        Autor a2 = new Autor("AU2", "Jorge Luis Borges", "Argentino");
        Autor a3 = new Autor("AU3", "Julio Cortázar", "Argentino");

        b.agregarLibro("L1", "Cien años de soledad", 1967, a1);
        b.agregarLibro("L2", "El Aleph", 1949, a2);
        b.agregarLibro("L3", "Rayuela", 1963, a3);
        b.agregarLibro("L4", "Ficciones", 1944, a2);
        b.agregarLibro("L5", "Bestiario", 1951, a3);

        System.out.println("LIBROS:");
        b.listarLibros();

        System.out.println("\nBuscar L3:");
        Libro buscado = b.buscarLibroPorIsbn("L3");
        if (buscado != null) buscado.mostrarInfo();

        System.out.println("\nAño 1949:");
        b.filtrarLibrosPorAnio(1949);

        b.eliminarLibro("L5");

        System.out.println("\nTotal libros: " + b.obtenerCantidadLibros());

        System.out.println("\nAutores:");
        b.mostrarAutoresDisponibles();
    }
}
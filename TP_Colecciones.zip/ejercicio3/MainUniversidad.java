public class MainUniversidad {

    public static void main(String[] args) {

        Universidad u = new Universidad("UTN");

        Profesor p1 = new Profesor("P1", "Ana López", "Programación");
        Profesor p2 = new Profesor("P2", "Luis Gómez", "Matemática");
        Profesor p3 = new Profesor("P3", "Carla Ruiz", "Física");

        Curso c1 = new Curso("C1", "Programación I");
        Curso c2 = new Curso("C2", "Álgebra");
        Curso c3 = new Curso("C3", "Física I");
        Curso c4 = new Curso("C4", "Programación II");
        Curso c5 = new Curso("C5", "Análisis Matemático");

        u.agregarProfesor(p1);
        u.agregarProfesor(p2);
        u.agregarProfesor(p3);

        u.agregarCurso(c1);
        u.agregarCurso(c2);
        u.agregarCurso(c3);
        u.agregarCurso(c4);
        u.agregarCurso(c5);

        u.asignarProfesorACurso("C1", "P1");
        u.asignarProfesorACurso("C4", "P1");
        u.asignarProfesorACurso("C2", "P2");
        u.asignarProfesorACurso("C5", "P2");
        u.asignarProfesorACurso("C3", "P3");

        System.out.println("CURSOS:");
        u.listarCursos();

        System.out.println("\nPROFESORES:");
        u.listarProfesores();

        System.out.println("\nReasignando profesor del curso C4...");
        u.asignarProfesorACurso("C4", "P3");

        u.listarCursos();

        System.out.println("\nEliminando curso C5...");
        u.eliminarCurso("C5");

        System.out.println("\nEliminando profesor P2...");
        u.eliminarProfesor("P2");

        System.out.println("\nCursos finales:");
        u.listarCursos();
    }
}
import java.util.ArrayList;

public class MainKata3 {
    public static void main(String[] args) {

        ArrayList<Empleado> empleados = new ArrayList<>();

        empleados.add(new EmpleadoPlanta("María", 200000));
        empleados.add(new EmpleadoTemporal("Jorge", 80, 1200));
        empleados.add(new EmpleadoPlanta("Lucía", 180000));

        for (Empleado e : empleados) {
            System.out.println(e + " - Sueldo: " + e.calcularSueldo());

            if (e instanceof EmpleadoPlanta) {
                System.out.println(" -> Es empleado de planta");
            } else if (e instanceof EmpleadoTemporal) {
                System.out.println(" -> Es empleado temporal");
            }
        }
    }
}
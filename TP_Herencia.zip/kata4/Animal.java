public class Animal {

    public void hacerSonido() {
        System.out.println("Sonido genérico...");
    }

    public void describirAnimal() {
        System.out.println("Soy un animal.");
    }
}
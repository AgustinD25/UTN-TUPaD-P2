public class MainKata1 {
    public static void main(String[] args) {
        Auto a = new Auto("Toyota", "Corolla", 5);
        a.mostrarInfo();
    }
}
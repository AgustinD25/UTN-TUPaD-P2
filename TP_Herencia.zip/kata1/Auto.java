public class Auto extends Vehiculo {

    private int cantidadPuertas;

    public Auto(String marca, String modelo, int puertas) {
        super(marca, modelo);
        this.cantidadPuertas = puertas;
    }

    @Override
    public void mostrarInfo() {
        System.out.println("Auto: " + marca + " " + modelo + " - Puertas: " + cantidadPuertas);
    }
}
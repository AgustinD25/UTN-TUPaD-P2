import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class MainExcepciones {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1. División segura
        System.out.println("=== División segura ===");
        try {
            System.out.print("Ingrese el numerador: ");
            int num = Integer.parseInt(sc.nextLine());
            System.out.print("Ingrese el denominador: ");
            int den = Integer.parseInt(sc.nextLine());

            int resultado = num / den;
            System.out.println("Resultado: " + resultado);
        } catch (ArithmeticException ex) {
            System.out.println("Error: no se puede dividir por cero.");
        } catch (NumberFormatException ex) {
            System.out.println("Error: debe ingresar números enteros.");
        }

        // 2. Conversión de cadena a número
        System.out.println("\n=== Conversión de cadena a número ===");
        System.out.print("Ingrese un número entero: ");
        String texto = sc.nextLine();
        try {
            int valor = Integer.parseInt(texto);
            System.out.println("El número ingresado es: " + valor);
        } catch (NumberFormatException ex) {
            System.out.println("Error: el texto ingresado no es un entero válido.");
        }

        // 3. Lectura de archivo con manejo de FileNotFoundException
        System.out.println("\n=== Lectura de archivo ===");
        File archivo = new File("datos.txt");
        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(archivo);
            System.out.println("Contenido de datos.txt:");
            while (fileScanner.hasNextLine()) {
                System.out.println(fileScanner.nextLine());
            }
        } catch (FileNotFoundException ex) {
            System.out.println("No se encontró el archivo datos.txt");
        } finally {
            if (fileScanner != null) {
                fileScanner.close();
            }
        }

        // 4. Excepción personalizada
        System.out.println("\n=== Verificación de edad ===");
        System.out.print("Ingrese una edad: ");
        String edadTexto = sc.nextLine();
        try {
            int edad = Integer.parseInt(edadTexto);
            validarEdad(edad);
            System.out.println("Edad válida: " + edad);
        } catch (NumberFormatException ex) {
            System.out.println("Debe ingresar un número entero para la edad.");
        } catch (EdadInvalidaException ex) {
            System.out.println("Error de edad: " + ex.getMessage());
        }

        // 5. try-with-resources para leer archivo
        System.out.println("\n=== Lectura de archivo con try-with-resources ===");
        try (BufferedReader br = new BufferedReader(new FileReader("datos.txt"))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("datos.txt no existe, no se puede leer.");
        } catch (IOException ex) {
            System.out.println("Ocurrió un problema al leer el archivo: " + ex.getMessage());
        }

        sc.close();
    }

    // lanza la excepción personalizada si la edad no está en un rango razonable
    private static void validarEdad(int edad) throws EdadInvalidaException {
        if (edad < 0 || edad > 120) {
            throw new EdadInvalidaException("La edad debe estar entre 0 y 120.");
        }
    }
}

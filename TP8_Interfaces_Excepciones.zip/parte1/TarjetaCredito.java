public class TarjetaCredito implements Pago, PagoConDescuento {

    private String numero;
    private String titular;

    public TarjetaCredito(String numero, String titular) {
        this.numero = numero;
        this.titular = titular;
    }

    @Override
    public double aplicarDescuento(double monto) {
        // simulamos un pequeño descuento por promoción
        return monto * 0.95; // 5% de descuento
    }

    @Override
    public void procesarPago(double monto) {
        System.out.println("Procesando pago con tarjeta de crédito por $" + monto);
    }
}

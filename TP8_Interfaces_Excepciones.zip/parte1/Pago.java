public interface Pago {
    void procesarPago(double monto);
}

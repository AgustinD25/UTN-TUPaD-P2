public interface PagoConDescuento {
    double aplicarDescuento(double monto);
}

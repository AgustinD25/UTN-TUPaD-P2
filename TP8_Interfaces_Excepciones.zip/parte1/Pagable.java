public interface Pagable {
    double calcularTotal();
}

public interface Notificable {
    void notificar(String mensaje);
}

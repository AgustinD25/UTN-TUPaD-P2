public class MainEcommerce {

    public static void main(String[] args) {

        Cliente cli = new Cliente("Agustín", "agus@example.com");
        Pedido pedido = new Pedido(cli);

        Producto prod1 = new Producto("Collar para perro", 2500);
        Producto prod2 = new Producto("Comida balanceada", 4300);
        Producto prod3 = new Producto("Juguete", 1800);

        pedido.agregarProducto(prod1);
        pedido.agregarProducto(prod2);
        pedido.agregarProducto(prod3);

        System.out.println("Productos en el pedido:");
        for (Producto p : pedido.getProductos()) {
            System.out.println(" - " + p);
        }

        double total = pedido.calcularTotal();
        System.out.println("Total del pedido: $" + total);

        // elegimos un medio de pago
        TarjetaCredito tarjeta = new TarjetaCredito("1111-2222-3333-4444", "Agustín");
        double totalConDescuento = tarjeta.aplicarDescuento(total);
        System.out.println("Total con descuento de tarjeta: $" + totalConDescuento);
        tarjeta.procesarPago(totalConDescuento);

        // cambiamos estado del pedido y se notifica al cliente
        pedido.cambiarEstado("PAGADO");
    }
}
